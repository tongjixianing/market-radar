#!/bin/bash
# Market Radar — double-click this on macOS to launch
cd "$(dirname "$0")"
java -jar market-radar.jar
